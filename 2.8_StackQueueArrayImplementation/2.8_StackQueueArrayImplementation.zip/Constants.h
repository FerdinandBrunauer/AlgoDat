#pragma once

#define MAX_ARRAY_SIZE 10